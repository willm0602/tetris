from SceneHandler import SceneHandler

main = SceneHandler()
main.run()

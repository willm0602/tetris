# TETRIS

This is my recreation of the popular game Tetris.


## Requirements
This program runs on python 3.6 with the only requirement being Pygame which can be installed by running
>pip install pygame


## Credits
all assets were made by me with the exception of the music which was made by playonloop.com

Background music from (https://www.playonloop.com/2018-music-loops/its-a-blast/)


